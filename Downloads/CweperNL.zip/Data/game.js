window.addEventListener("DOMContentLoaded", () => {
  // world dimensions
  const WORLD_W = 1920, WORLD_H = 1080;

  let socket          = null,
      myId            = null,
      currentServer   = null,
      gameLoopStarted = false;

  const players = {}, trees = [], stones = [];
  let treeScore = 0, stoneScore = 0;

  // DOM refs
  const canvas       = document.getElementById("Canvas"),
        ctx          = canvas.getContext("2d"),
        serverSelect = document.getElementById("serverSelect"),
        customInput  = document.getElementById("customServer"),
        connectBtn   = document.querySelector("button[onclick='connectToServer()']"),
        chatInput    = document.getElementById("chat-input"),
        chatMessages = document.getElementById("chat-messages"),
        scoreDisplay = document.getElementById("score"),
        mineSound    = document.getElementById("mine-sound");

  const keys = {};
  connectBtn.disabled = true;

  // track WS keypresses
  document.addEventListener("keydown", e => keys[e.key.toLowerCase()] = true);
  document.addEventListener("keyup",   e => keys[e.key.toLowerCase()] = false);

  // toggle custom‐URL input
  serverSelect.addEventListener("change", () => {
    customInput.style.display = serverSelect.value === "custom"
      ? "inline-block" : "none";
    connectBtn.disabled = serverSelect.value === currentServer;
  });

  function getUsername() {
    const n = localStorage.getItem("Username");
    return n && n.trim() ? n.trim() : "Anonymous";
  }

  function updateScoreDisplay() {
    // ensure it’s visible any time it’s updated
    scoreDisplay.style.display = "block";
    scoreDisplay.textContent =
      `Trees mined: ${treeScore} | Stones mined: ${stoneScore}`;
  }

  // scale CSS to fill viewport
  function resizeToFit() {
    const vw    = window.innerWidth,
          vh    = window.innerHeight,
          scale = Math.min(vw / WORLD_W, vh / WORLD_H),
          cw    = Math.floor(WORLD_W * scale),
          ch    = Math.floor(WORLD_H * scale),
          mvert = Math.floor((vh - ch) / 2);

    canvas.style.width  = `${cw}px`;
    canvas.style.height = `${ch}px`;
    canvas.style.marginTop    = `${mvert}px`;
    canvas.style.marginBottom = `${mvert}px`;
  }
  window.addEventListener("resize", resizeToFit);

  // chat Enter → emit
  chatInput.addEventListener("keydown", e => {
    if (e.key === "Enter" &&
        chatInput.value.trim() &&
        socket && socket.connected) {

      socket.emit("chat_message", {
        text:     chatInput.value.trim(),
        username: getUsername()
      });
      chatInput.value = "";
    }
  });

  // connect button handler
  function connectToServer() {
    let url = serverSelect.value;
    if (url === "custom") {
      url = customInput.value.trim();
      if (!url) { alert("Enter server URL"); return; }
    }
    if (url === currentServer) {
      alert("Already connected!"); return;
    }

    // teardown old connection
    if (socket) {
      socket.disconnect();
      socket = null;
      myId = null;
      Object.keys(players).forEach(id => delete players[id]);
      trees.length    = stones.length = 0;
      chatMessages.innerHTML = "";
      treeScore = stoneScore = 0;
      // we’ll re-show once init fires
      scoreDisplay.style.display = "none";
    }

    currentServer = url;
    connectBtn.disabled = true;
    console.log(`[Client] Connecting to ${url}`);
    socket = io(url, { timeout: 5000 });

    // socket events
    socket.on("connect", () => {
      console.log(`[Socket] Connected as ${socket.id}`);
    });
    socket.on("connect_error", () => {
      alert("Connection failed, reloading...");
      location.reload();
    });
    socket.on("disconnect", () => {
      alert("Disconnected from server.");
      currentServer = null;
      connectBtn.disabled = false;
    });

    socket.on("init", data => {
      console.log("[Socket] init:", data);
      myId = data.id;
      Object.assign(players, data.players);

      // set up world buffer + scale
      canvas.width  = WORLD_W;
      canvas.height = WORLD_H;
      resizeToFit();

      // load resources
      trees.length = stones.length = 0;
      if (Array.isArray(data.trees))  trees.push(...data.trees);
      if (Array.isArray(data.stones)) stones.push(...data.stones);

      // reset & reveal score
      treeScore = stoneScore = 0;
      updateScoreDisplay();
    });

    socket.on("player_joined", d => {
      console.log("[Socket] player_joined:", d.id);
      players[d.id] = { x:d.x, y:d.y };
    });
    socket.on("update_position", d => {
      if (players[d.id]) {
        players[d.id].x = d.x;
        players[d.id].y = d.y;
      }
    });
    socket.on("player_left", d => {
      console.log("[Socket] player_left:", d.id);
      delete players[d.id];
    });

    socket.on("chat_message", d => {
      console.log("[Socket] chat_message:", d);
      const el = document.createElement("div");
      const you  = d.id === myId;
      const name = you ? "You" : d.username;
      el.textContent = `${name}: ${d.text}`;
      chatMessages.appendChild(el);
      chatMessages.scrollTop = chatMessages.scrollHeight;
    });

    socket.on("resource_mined", d => {
      console.log("[Socket] resource_mined:", d);
      const arr = d.type === "tree" ? trees : stones;
      const idx = arr.findIndex(r => r.x === d.x && r.y === d.y);
      if (idx !== -1) arr.splice(idx,1);

      if (d.playerId === myId) {
        if (d.type === "tree") treeScore++;
        else stoneScore++;
        updateScoreDisplay();
        mineSound.currentTime = 0;
        mineSound.play().catch(()=>{});
      }
    });

    // start render loop
    if (!gameLoopStarted) {
      gameLoopStarted = true;
      requestAnimationFrame(loop);
    }
  }

  // movement emitter
  function sendMovement() {
    let dx=0, dy=0;
    if (keys["w"]) dy -= 2;
    if (keys["s"]) dy += 2;
    if (keys["a"]) dx -= 2;
    if (keys["d"]) dx += 2;
    if ((dx||dy) && socket) {
      socket.emit("move", { dx, dy });
    }
  }

  // click to mine
  canvas.addEventListener("click", e => {
    if (!socket || !myId || !players[myId]) return;

    const rect   = canvas.getBoundingClientRect(),
          scaleX = canvas.width  / rect.width,
          scaleY = canvas.height / rect.height,
          cx     = (e.clientX - rect.left ) * scaleX,
          cy     = (e.clientY - rect.top  ) * scaleY;

    const p = players[myId];
    if (Math.hypot(p.x-cx, p.y-cy) > 50) return;

    for (const t of trees) {
      if (Math.hypot(t.x-cx, t.y-cy) < 30) {
        socket.emit("mine", { type:"tree", x:t.x, y:t.y });
        return;
      }
    }
    for (const s of stones) {
      if (Math.hypot(s.x-cx, s.y-cy) < 30) {
        socket.emit("mine", { type:"stone", x:s.x, y:s.y });
        return;
      }
    }
  });

  // drawing functions
  function drawBackground() {
    ctx.fillStyle = "#2c7a2c";
    ctx.fillRect(0,0,WORLD_W,WORLD_H);
  }
  function drawTrees() {
    for (const t of trees) {
      ctx.fillStyle = "#654321";
      ctx.fillRect(t.x-5,t.y,10,30);
      ctx.beginPath();
      ctx.fillStyle = "#228B22";
      ctx.arc(t.x,t.y,20,0,Math.PI*2);
      ctx.fill();
    }
  }
  function drawStones() {
    for (const s of stones) {
      ctx.fillStyle = "#888";
      ctx.beginPath();
      ctx.arc(s.x,s.y,15,0,Math.PI*2);
      ctx.fill();
    }
  }
  function drawPlayers() {
    for (const id in players) {
      const p = players[id];
      ctx.fillStyle = id===myId ? "blue" : "red";
      ctx.fillRect(p.x,p.y,20,20);
    }
  }
  function loop() {
    drawBackground();
    drawTrees();
    drawStones();
    drawPlayers();
    sendMovement();
    requestAnimationFrame(loop);
  }

  window.connectToServer = connectToServer;
});
