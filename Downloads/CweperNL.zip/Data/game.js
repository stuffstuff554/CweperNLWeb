window.addEventListener("DOMContentLoaded", () => {
  let socket = null;
  let myId = null;
  let currentServer = null;
  let gameLoopStarted = false;
  const players = {};
  const canvas = document.getElementById("Canvas");
  const ctx = canvas.getContext("2d");
  const keys = {};

  const connectBtn = document.querySelector("button[onclick='connectToServer()']");
  const serverSelect = document.getElementById("serverSelect");
  const customInput = document.getElementById("customServer");
  const chatInput = document.getElementById("chat-input");
  const chatMessages = document.getElementById("chat-messages");

  connectBtn.disabled = true;

  document.addEventListener("keydown", e => keys[e.key.toLowerCase()] = true);
  document.addEventListener("keyup", e => keys[e.key.toLowerCase()] = false);

  serverSelect.addEventListener("change", () => {
    const selected = serverSelect.value;
    customInput.style.display = selected === "custom" ? "inline-block" : "none";
    connectBtn.disabled = (selected === currentServer) && currentServer !== null;
  });

  const trees = Array.from({ length: 50 }, () => ({
    x: Math.random() * canvas.width,
    y: Math.random() * (canvas.height * 0.8) + canvas.height * 0.1
  }));

  function getUsername() {
    const name = localStorage.getItem("Username");
    return name && name.trim() !== "" ? name.trim() : "Anonymous";
  }

  function connectToServer() {
    let url = serverSelect.value;
    if (url === "custom") {
      url = customInput.value.trim();
      if (!url) {
        alert("Please enter a server URL.");
        return;
      }
    }

    if (url === currentServer && currentServer !== null) {
      alert("You are already connected to this server.");
      return;
    }

    // Disconnect and clean previous socket if any
    if (socket) {
      socket.disconnect();
      socket = null;
      myId = null;
      for (const id in players) delete players[id];
    }

    currentServer = url;
    connectBtn.disabled = true;

    socket = io(url, { timeout: 5000 });

    socket.on("connect_error", () => {
      alert("Failed to connect to server. Reloading page.");
      location.reload();
    });

    socket.on("disconnect", () => {
      alert("Disconnected from server.");
      currentServer = null;
      connectBtn.disabled = false;
    });

    socket.on("init", data => {
      myId = data.id;
      Object.assign(players, data.players);
    });

    socket.on("player_joined", data => {
      players[data.id] = { x: data.x, y: data.y };
    });

    socket.on("update_position", data => {
      if (players[data.id]) {
        players[data.id].x = data.x;
        players[data.id].y = data.y;
      }
    });

    socket.on("player_left", data => {
      delete players[data.id];
    });

    socket.on("chat_message", data => {
      const el = document.createElement("div");
      let sender;
      if (data.id === myId) {
        sender = "You";
      } else if (data.username && data.username.trim()) {
        sender = data.username.trim();
      } else {
        sender = `Player ${data.id.slice(0, 5)}`;
      }
      el.textContent = `${sender}: ${data.text}`;
      chatMessages.appendChild(el);
      chatMessages.scrollTop = chatMessages.scrollHeight;
    });

    // Start the game loop only once
    if (!gameLoopStarted) {
      gameLoopStarted = true;
      loop();
    }
  }

  function sendMovement() {
    let dx = 0, dy = 0;
    if (keys["w"]) dy -= 2;
    if (keys["s"]) dy += 2;
    if (keys["a"]) dx -= 2;
    if (keys["d"]) dx += 2;

    if ((dx !== 0 || dy !== 0) && socket) {
      socket.emit("move", { dx, dy });
    }
  }

  chatInput.addEventListener("keydown", e => {
    if (e.key === "Enter" && chatInput.value.trim() !== "" && socket) {
      socket.emit("chat_message", {
        text: chatInput.value.trim(),
        username: getUsername()
      });
      chatInput.value = "";
    }
  });

  function drawBackgroundAndTrees() {
    ctx.fillStyle = "#2c7a2c";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    for (const tree of trees) {
      ctx.fillStyle = "#654321";
      ctx.fillRect(tree.x - 5, tree.y, 10, 30);

      ctx.beginPath();
      ctx.fillStyle = "#228B22";
      ctx.arc(tree.x, tree.y, 20, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  function drawPlayers() {
    drawBackgroundAndTrees();

    for (const id in players) {
      const p = players[id];
      ctx.fillStyle = id === myId ? "blue" : "red";
      ctx.fillRect(p.x, p.y, 20, 20);
    }
  }

  function loop() {
    sendMovement();
    drawPlayers();
    requestAnimationFrame(loop);
  }

  window.connectToServer = connectToServer;
});
