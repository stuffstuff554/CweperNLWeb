// home.js — Created by Cweper NL, South Australia

const ServerAddress = "http://cwepernls.duckdns.org:5000/receive";

// Function to send JSON to server and return parsed response
async function sendMessage(jsonData) {
    try {
        const response = await fetch(ServerAddress, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(jsonData)
        });
        return await response.json();
    } catch (error) {
        console.error("[sendMessage] Network or parsing error:", error);
        throw error;
    }
}

// Display current date in Australian format
const CurrentDate = new Date();
const formattedDate = CurrentDate.toLocaleDateString('en-AU');

const dateElement = document.getElementById("CurrentDate");
if (dateElement) {
    dateElement.textContent = formattedDate + " ";
    dateElement.addEventListener("mouseover", () => {
        dateElement.textContent = "(Australian Format Day/Month/Year) ";
    });
    dateElement.addEventListener("mouseout", () => {
        dateElement.textContent = formattedDate + " ";
    });
}

// Get credentials from localStorage
const UserCode = localStorage.getItem("UserCode");
const Username = localStorage.getItem("Username");

// Redirect if not logged in
if (!UserCode || !Username) {
    alert("You are not logged in. Redirecting to login page...");
    window.location.href = "login.html";  // Make sure this matches your actual login file
} else {
    Promise.all([
        sendMessage({ MSG: "3", Code: UserCode }), // Balance
        sendMessage({ MSG: "4", Code: UserCode })  // Username
    ])
    .then(([balanceResponse, usernameResponse]) => {
        if (!balanceResponse.success || !usernameResponse.success) {
            alert("An error occurred with your account. Redirecting to login...");
            localStorage.clear();
            window.location.href = "login.html";
            return;
        }

        const balance = balanceResponse.Balance;
        const username = usernameResponse.Username;

        const userInfo = `Username: ${username}, Balance: ${balance}`;
        const userInfoElem = document.getElementById("UserInfo");
        if (userInfoElem) {
            userInfoElem.textContent = userInfo;
        }
    })
    .catch(error => {
        alert("A fatal error occurred: " + error);
        localStorage.clear(); 
        window.location.href = "login.html";
    });
}
