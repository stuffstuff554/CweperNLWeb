// Cweper NL, South Australia
//
// Edited by ChatGPT, OpenAI

const ServerAddress = "http://cwepernls.duckdns.org:5000/receive";

async function sendMessage(jsonData) {
    console.log("[sendMessage] Sending JSON:", jsonData);
    try {
        const response = await fetch(ServerAddress, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(jsonData)
        });
        console.log("[sendMessage] Fetch complete, awaiting JSON parse...");
        const data = await response.json();
        console.log("[sendMessage] Server response JSON:", data);
        return data;
    } catch (error) {
        console.error("[sendMessage] Error during fetch or JSON parsing:", error);
        return { success: false, error: "Server error or invalid JSON" };
    }
}

function LogOn() {
    const TempUsername = document.getElementById("Login_Username").value;
    const TempPassword = document.getElementById("Login_Password").value;

    if (TempUsername === "" || TempPassword === "") {
        alert("ERR: You have to input both username and password!");
        return;
    }

    sendMessage({
        MSG: "2",
        Username: TempUsername,
        Password: TempPassword
    }).then(response => {
        if (response.success) {
            alert("Login successful! Your code: " + response.Code);
            // Store login data in localStorage (persists across tabs)
            localStorage.setItem("UserCode", response.Code);
            localStorage.setItem("Username", TempUsername);
            window.location.href = "home.html";
        } else {
            alert("Login failed: " + response.error);
        }
    }).catch(error => {
        console.error("Request error:", error);
        alert("Something went wrong with the server.");
    });
}

function Register() {
    console.log("[Register] Triggered account registration");

    const TempUsername = document.getElementById("Register_Username").value;
    const TempPassword = document.getElementById("Register_Password").value;

    console.log("[Register] Username input:", TempUsername);
    console.log("[Register] Password input:", TempPassword);

    if (TempUsername === "" || TempPassword === "") {
        console.warn("[Register] Username and password are NOT filled");
        alert("ERR: You have to input both a username and password to register!");
    } else {
        console.log("[Register] Inputs valid, sending account creation request");

        sendMessage({
            MSG: "1",
            Username: TempUsername,
            Password: TempPassword
        }).then(response => {
            console.log("[Register] Server responded:", response);
            if (response.success) {
                alert("Register successful!");
                localStorage.setItem("UserCode", response.Code);
                localStorage.setItem("Username", TempUsername);
                console.log("[Register] Stored UserCode and Username in localStorage");
            } else {
                alert("Register failed: " + response.error);
                console.warn("[Register] Register failed:", response.error);
            }
        }).catch(error => {
            console.error("[Register] Request error:", error);
            alert("Something went wrong with the server.");
        });

        console.log("[Register] sendMessage has been called");
    }
}
