import eventlet
eventlet.monkey_patch()

from flask import Flask, request
from flask_socketio import SocketIO, emit
import random

app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="*")

# world dims → 1920×1080
WIDTH, HEIGHT = 1920, 1080

players = {}
trees = []
stones = []

def generate_resources():
    global trees, stones
    trees = [
      {"x": random.randint(50, WIDTH - 50),
       "y": random.randint(50, HEIGHT - 50)}
      for _ in range(80)
    ]
    stones = [
      {"x": random.randint(50, WIDTH - 50),
       "y": random.randint(50, HEIGHT - 50)}
      for _ in range(50)
    ]

generate_resources()

@socketio.on("connect")
def on_connect():
    pid = request.sid
    players[pid] = {
      "x": random.randint(100, WIDTH - 100),
      "y": random.randint(100, HEIGHT - 100)
    }
    print(f"[Server] Player connected: {pid}")

    emit("init", {
      "id":      pid,
      "players": players,
      "trees":   trees,
      "stones":  stones,
      "width":   WIDTH,
      "height":  HEIGHT
    })

    emit("player_joined",
         {"id": pid, **players[pid]},
         broadcast=True,
         include_self=False)

@socketio.on("disconnect")
def on_disconnect():
    pid = request.sid
    if pid in players:
        print(f"[Server] Player disconnected: {pid}")
        del players[pid]
        emit("player_left", {"id": pid}, broadcast=True)

@socketio.on("move")
def on_move(data):
    pid = request.sid
    if pid not in players:
        return
    dx = data.get("dx", 0)
    dy = data.get("dy", 0)
    x  = max(0, min(WIDTH,  players[pid]["x"] + dx))
    y  = max(0, min(HEIGHT, players[pid]["y"] + dy))
    players[pid]["x"], players[pid]["y"] = x, y
    emit("update_position",
         {"id": pid, "x": x, "y": y},
         broadcast=True)

@socketio.on("mine")
def on_mine(data):
    pid = request.sid
    if pid not in players:
        return

    rtype = data.get("type")
    x, y  = data.get("x"), data.get("y")
    px, py = players[pid]["x"], players[pid]["y"]

    if ((px - x)**2 + (py - y)**2)**0.5 > 50:
        return

    resource_list = (
      trees if rtype == "tree"
      else stones if rtype == "stone"
      else None
    )
    if not resource_list:
        return

    for i, r in enumerate(resource_list):
        if r["x"] == x and r["y"] == y:
            del resource_list[i]
            print(f"[Server] Player {pid} mined a {rtype} at ({x},{y})")
            emit("resource_mined",
                 {"type": rtype, "x": x, "y": y, "playerId": pid},
                 broadcast=True)
            break

@socketio.on("chat_message")
def on_chat(data):
    # log it server-side
    text = data.get("text", "")
    user = data.get("username", "Anonymous")
    sid  = request.sid
    print(f"[Server][Chat] {sid} ({user}): {text}")

    # rebroadcast to all clients
    emit("chat_message", {
        "id":       sid,
        "username": user,
        "text":     text
    }, broadcast=True)

if __name__ == "__main__":
    print("Booting Cweper NL Server…")
    socketio.run(app, host="0.0.0.0", port=4999)
